﻿using EMS.BusinessLogic.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EMS.Controllers
{
    public class HomeController : Controller
    {
        EmployeeManager employeeManager = new EmployeeManager();

        public ActionResult Index()
        {
            return View();
        }        
    
    }
}