﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessEntities
{
    public class Project
    {
        public int ProjId { get; set; }
        public string Name { get; set; }
        public Nullable<decimal> Cost { get; set; }
    }
}
