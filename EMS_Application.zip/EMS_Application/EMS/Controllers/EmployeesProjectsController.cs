﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EMS.BusinessLogic.Manager;
using EMS.Models;

namespace EMS.Controllers
{
    public class EmployeesProjectsController : Controller
    {
        EmployeeManager employeeManager = new EmployeeManager();
        ProjectManager projectmanager = new ProjectManager();
        private EmpDBEntities db = new EmpDBEntities();
        TblEmployee emp = new TblEmployee();
        TblProject proj = new TblProject();
        TblEmployeeProject EmpProject = new TblEmployeeProject();
        View_EmployeeProject view_EmployeeProject = new View_EmployeeProject();

        // GET: EmployeesProjects
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult GetData()
        {
            var query = employeeManager.GetEmployeeProject().OrderBy(a => a.Name).ToList();
            return Json(new { data = query }, JsonRequestBehavior.AllowGet);

        }


        // GET: EmployeesProjects/Create
        public ActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Name,Cost,FirstName,LastName,JoiningDate,EmpId,ProjId,Salary")] View_EmployeeProject view_EmployeeProject)
        {


            if (ModelState.IsValid)
            {
                emp.FirstName = view_EmployeeProject.FirstName;
                emp.LastName = view_EmployeeProject.LastName;
                emp.JoiningDate = view_EmployeeProject.JoiningDate;
                emp.Salary = view_EmployeeProject.Salary;

                var employeeExistst = db.TblEmployees.Where(x => x.FirstName == view_EmployeeProject.FirstName && x.LastName == view_EmployeeProject.LastName).FirstOrDefault();
                var projectExistst = db.TblProjects.Where(x => x.Name == view_EmployeeProject.Name).FirstOrDefault();


                proj.Cost = view_EmployeeProject.Cost;
                proj.Name = view_EmployeeProject.Name;

                if (employeeExistst == null && projectExistst == null)
                {
                    var empId = employeeManager.Save(emp);
                    var projId = projectmanager.Save(proj);


                    //EmpProject.EmpId = empId;
                    //EmpProject.ProjId = projId;
                    //db.TblEmployeeProjects.Add(EmpProject);
                    //var data = db.SaveChanges();

                    if (empId > 0 || projId > 0 )
                    {

                        return RedirectToAction("Index");
                    }
                }
            }

            return View(view_EmployeeProject);
        }

        //// GET: EmployeesProjects/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
          
            var employeeProject = db.TblEmployeeProjects.Where(x => x.Id == id).FirstOrDefault();

            if (employeeProject != null)
            {
                var project = db.TblProjects.Where(y => y.ProjId == employeeProject.ProjId).FirstOrDefault();


                var employee = db.TblEmployees.Where(y => y.EmpId == employeeProject.EmpId).FirstOrDefault();

                view_EmployeeProject.ProjId = employeeProject.ProjId.Value;
                view_EmployeeProject.EmpId = employeeProject.EmpId.Value;
                view_EmployeeProject.Name = project.Name;
                view_EmployeeProject.Cost = project.Cost;
                view_EmployeeProject.FirstName = employee.FirstName;
                view_EmployeeProject.LastName = employee.LastName;
                view_EmployeeProject.JoiningDate = employee.JoiningDate;
                view_EmployeeProject.Salary = employee.Salary;
            }
                if (employeeProject == null)
                {
                    return HttpNotFound();
                }
            
            return View(view_EmployeeProject);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Name,Cost,FirstName,LastName,JoiningDate,EmpId,ProjId,Salary")] View_EmployeeProject view_EmployeeProject)
        {

            if (ModelState.IsValid)
            {
                emp.FirstName = view_EmployeeProject.FirstName;
                emp.LastName = view_EmployeeProject.LastName;
                emp.JoiningDate = view_EmployeeProject.JoiningDate;
                emp.EmpId = view_EmployeeProject.EmpId;
                emp.Salary = view_EmployeeProject.Salary;

                var empdata = employeeManager.Update(emp);

                proj.Cost = view_EmployeeProject.Cost;
                proj.Name = view_EmployeeProject.Name;
                proj.ProjId = view_EmployeeProject.ProjId;

                var projdata = projectmanager.Update(proj);

                if (empdata > 0 || projdata > 0)
                {
                    return RedirectToAction("Index");
                }
            }
            return View(view_EmployeeProject);
        }

        // GET: EmployeesProjects/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //var data = employeeManager.GetEmployeeByid(id);
            view_EmployeeProject = db.View_EmployeeProject.Where(a=> a.Id == id).SingleOrDefault();
            if (view_EmployeeProject == null)
            {
                return HttpNotFound();
            }
            return View(view_EmployeeProject);
        }

        // POST: EmployeesProjects/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            view_EmployeeProject = db.View_EmployeeProject.Where(a => a.Id == id).SingleOrDefault();
            EmpProject = db.TblEmployeeProjects.Where(a => a.Id == id).SingleOrDefault();
            
            db.TblEmployeeProjects.Remove(EmpProject);
            var data = db.SaveChanges();

            if (data > 0)
            {               
                return RedirectToAction("Index");
            }

            return View(view_EmployeeProject);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
