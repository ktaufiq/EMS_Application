﻿using EMS.BusinessEntities;
using EMS.Models;
using EMS.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Repository.Manager
{
    public class ProjectRepository : IProjectRepository
    {

        EmpDBEntities context = new EmpDBEntities();
        public IEnumerable<TblProject> Get()  // It's return All Employee List
        {
            return context.TblProjects.ToList();
        }

        public TblProject Get(int? Id)   // It's return Employee Base on Employee Id
        {
            return context.TblProjects.FirstOrDefault(e => e.ProjId == Id);
        }

        public int Save(TblProject project)
        {
            var proj = new TblProject()
            {
               
                Name = project.Name,
                Cost = project.Cost

            };
            context.TblProjects.Add(proj);

            context.SaveChanges();
            return proj.ProjId;
        }

        public int Update(TblProject project)
        {
            var _project = context.TblProjects.Where(e => e.ProjId == project.ProjId).SingleOrDefault();
            _project.ProjId = project.ProjId;
            _project.Name = project.Name;
            _project.Cost = project.Cost;
            return context.SaveChanges();
        }

        public int Delete(int ProjId)
        {
            var _project = context.TblProjects.Where(e => e.ProjId == ProjId).SingleOrDefault();
            context.TblProjects.Remove(_project);
            return context.SaveChanges();
        }
    }
}
