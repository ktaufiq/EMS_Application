﻿using EMS.BusinessEntities;
using EMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessLogic.Interface
{
    public interface IEmployeeManager
    {

        IEnumerable<TblEmployee> GetEmployee();
        IEnumerable<EmployeesProjects> GetEmployeeProject();
        TblEmployee GetEmployeeByid(int? Id);
        int Save(TblEmployee employee);

        int Update(TblEmployee employee);

        int Delete(int empId);

    }
}
