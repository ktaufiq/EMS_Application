﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EMS.Models;

namespace EMS.Controllers
{
    public class EmployeeProjectsController : Controller
    {
        private EmpDBEntities db = new EmpDBEntities();

        // GET: EmployeeProjects
        public ActionResult Index()
        {
            var tblEmployeeProjects = db.TblEmployeeProjects.Include(t => t.TblEmployee).Include(t => t.TblProject);
            return View(tblEmployeeProjects.ToList());
        }

        // GET: EmployeeProjects/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TblEmployeeProject tblEmployeeProject = db.TblEmployeeProjects.Find(id);
            if (tblEmployeeProject == null)
            {
                return HttpNotFound();
            }
            return View(tblEmployeeProject);
        }

        // GET: EmployeeProjects/Create
        public ActionResult Create()
        {
            ViewBag.EmpId = new SelectList(db.TblEmployees, "EmpId", "FirstName");
            ViewBag.ProjId = new SelectList(db.TblProjects, "ProjId", "Name");
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,EmpId,ProjId")] TblEmployeeProject tblEmployeeProject)
        {
            if (ModelState.IsValid)
            {
                db.TblEmployeeProjects.Add(tblEmployeeProject);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EmpId = new SelectList(db.TblEmployees, "EmpId", "FirstName", tblEmployeeProject.EmpId);
            ViewBag.ProjId = new SelectList(db.TblProjects, "ProjId", "Name", tblEmployeeProject.ProjId);
            return View(tblEmployeeProject);
        }

       

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
