﻿using EMS.BusinessEntities;
using EMS.Models;
using EMS.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Repository.Manager
{
    public class EmployeeRepository : IEmployeeRepository
    {
        EmpDBEntities context = new EmpDBEntities();

        public IEnumerable<TblEmployee> Get()  // It's return All Employee List
        {
            return context.TblEmployees.ToList();
        }

       public IEnumerable<EmployeesProjects> GetEmployeeProject()
        {
            return context.Database.SqlQuery<EmployeesProjects>(
             "exec GetEmployeeProject ").ToList<EmployeesProjects>();
         //   return context..ToList();

        }

        public TblEmployee Get(int? empId)   // It's return Employee Base on Employee Id
        {
            return context.TblEmployees.FirstOrDefault(e => e.EmpId == empId);
        }

        public int Save(TblEmployee employee)
        {
          
            context.TblEmployees.Add(employee);

             context.SaveChanges();
            return employee.EmpId;
        }

        public int Update(TblEmployee employee)
        {
            var emp = context.TblEmployees.Where(e => e.EmpId == employee.EmpId).SingleOrDefault();
            emp.EmpId = employee.EmpId;
            emp.FirstName = employee.FirstName;
            emp.LastName = employee.LastName;
            emp.JoiningDate = employee.JoiningDate;
            emp.Salary = employee.Salary;            
            return context.SaveChanges();
        }

        public int Delete(int empId)
        {
            var emp = context.TblEmployees.Where(e => e.EmpId == empId).SingleOrDefault();  
            context.TblEmployees.Remove(emp);
            return context.SaveChanges();
        }
    }
}
