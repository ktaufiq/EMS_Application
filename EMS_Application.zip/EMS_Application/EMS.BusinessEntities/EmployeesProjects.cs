﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessEntities
{
    public  class EmployeesProjects
    {
        public string FullName { get; set; }
        public string Name { get; set; }
        public Nullable<decimal> Cost { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string JoiningDate { get; set; }
 
        public int EmpId { get; set; }

        public int ProjId { get; set; }
        public Nullable<decimal> Salary { get; set; }
        public int Id { get; set; }
    }
}
