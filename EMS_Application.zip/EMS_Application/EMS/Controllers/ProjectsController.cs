﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EMS.BusinessLogic.Manager;
using EMS.Models;

namespace EMS.Controllers
{
    public class ProjectsController : Controller
    {
        ProjectManager projectmanager = new ProjectManager();
        private EmpDBEntities db = new EmpDBEntities();
        public ActionResult Index()
        {
            return View(projectmanager.Get());
        }

        
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TblProject tblProject = projectmanager.Get(id);
            if (tblProject == null)
            {
                return HttpNotFound();
            }
            return View(tblProject);
        }

       
        public ActionResult Create()
        {
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProjId,Name,Cost")] TblProject tblProject)
        {
            if (ModelState.IsValid)
            {
                var projectExistst = db.TblProjects.Where(x => x.Name == tblProject.Name).FirstOrDefault();

                if (projectExistst == null)
                {
                    var data = projectmanager.Save(tblProject);
                    if (data > 0)
                    {
                        return RedirectToAction("Index");
                    }
                }
            }

            return View(tblProject);
        }

      
      
    }
}
