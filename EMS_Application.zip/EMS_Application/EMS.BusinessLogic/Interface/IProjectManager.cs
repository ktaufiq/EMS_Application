﻿using EMS.BusinessEntities;
using EMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessLogic.Interface
{
   public interface IProjectManager
    {
        IEnumerable<TblProject> Get();
        TblProject Get(int? ProjId);
        int Save(TblProject project);

        int Update(TblProject project);

        int Delete(int Id);
    }
}
