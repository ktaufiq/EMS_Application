﻿using EMS.BusinessEntities;
using EMS.BusinessLogic.Interface;
using EMS.Models;
using EMS.Repository.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessLogic.Manager
{
    public class ProjectManager : IProjectManager
    {

        ProjectRepository projectRepository = new ProjectRepository();
       

        public IEnumerable<TblProject> Get()  
        {
            return projectRepository.Get();
        }

        public TblProject Get(int? empId)  
        {
            return projectRepository.Get(empId);
        }

        public int Save(TblProject project)
        {


            return projectRepository.Save(project);
        }

        public int Update(TblProject project)
        {
            return projectRepository.Update(project);
        }

        public int Delete(int id)
        {
            return projectRepository.Delete(id);
        }
    }
}
