﻿using EMS.BusinessEntities;
using EMS.BusinessLogic.Interface;
using EMS.Models;
using EMS.Repository.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessLogic.Manager
{
   public class EmployeeManager: IEmployeeManager
    {
        EmployeeRepository employeeRepository = new EmployeeRepository(); 
      
        public IEnumerable<TblEmployee> GetEmployee()  // It's return All Employee List
        {
            return employeeRepository.Get();
        }
        public IEnumerable<EmployeesProjects> GetEmployeeProject()
        {
            return employeeRepository.GetEmployeeProject();
        }
        public TblEmployee GetEmployeeByid(int? empId)   // It's return Employee Base on Employee Id
        {
            return employeeRepository.Get(empId);
        }

        public int Save(TblEmployee employee)
        {


            return employeeRepository.Save(employee);
        }

        public int Update(TblEmployee employee)
        {
            return employeeRepository.Update(employee);
        }

        public int Delete(int empId)
        {
            return employeeRepository.Delete(empId);
        }
    }
}
