﻿using EMS.BusinessEntities;
using EMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Repository.Interface
{
    public interface IEmployeeRepository
    {
        IEnumerable<TblEmployee> Get();
        IEnumerable<EmployeesProjects> GetEmployeeProject();
        TblEmployee Get(int? empId);
        int Save(TblEmployee employee);

        int Update(TblEmployee employee);

        int Delete(int empId);
    }
}
